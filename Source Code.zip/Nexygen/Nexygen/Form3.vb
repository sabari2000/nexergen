﻿Public Class Form3

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        TextBox1.Text = My.Computer.Info.TotalPhysicalMemory
        TextBox2.Text = My.Computer.Info.AvailablePhysicalMemory
        TextBox3.Text = My.Computer.Info.TotalVirtualMemory
        TextBox4.Text = My.Computer.Info.AvailableVirtualMemory
    End Sub
End Class