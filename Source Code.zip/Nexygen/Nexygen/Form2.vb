﻿Public Class Form2

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub Timer1_Tick_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        TextBox1.Text = System.Environment.MachineName
        TextBox2.Text = System.Environment.UserName
        TextBox3.Text = My.Computer.Info.OSFullName
        TextBox4.Text = My.Computer.Info.OSPlatform
        TextBox5.Text = My.Computer.Info.OSVersion
        TextBox6.Text = My.Computer.Info.TotalPhysicalMemory
    End Sub
End Class